package sample;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import org.jetbrains.annotations.NotNull;

public class Main extends Application {

    private Controller controller;

    @Override
    public void start(Stage primaryStage) throws Exception{

        FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
        GridPane rootGridpane = loader.load();

        controller = loader.getController();
        controller.createPlayground(); //to create a white rectagle in pane2


        //to call menubar
        MenuBar menuBar = createMenu();

       Pane menupane = (Pane) rootGridpane.getChildren().get(0); //we take 0th pane i.e pane which is assigned to coloumn spam of 2 (1st pane )
        menupane.getChildren().add(menuBar);


menuBar.prefWidthProperty().bind(primaryStage.widthProperty());
//here we stretch the menubar to whole pane ; before this code the menubar will be shown only to the extend  where the items are present

        Scene scene = new Scene(rootGridpane);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Connect 4 game");
        primaryStage.setResizable(false);

        primaryStage.show();


    }




    @NotNull
    private MenuBar  createMenu(){


        //file menu

        Menu  fileMenu = new Menu("File");

//----------------------------------------------------------
        MenuItem newGame = new MenuItem("New Game");
        //On click
        newGame.setOnAction(event -> ResetGame() );
//----------------------------------------------------------

        MenuItem resetGame = new MenuItem("Reset Game");
        //On click
        resetGame.setOnAction(event -> ResetGame());

//------------------------------------------------------------
        MenuItem quit = new MenuItem("Quit");
        //On click
        quit.setOnAction(event -> Quit() );

//-----------------------------------------------------------
        SeparatorMenuItem line = new SeparatorMenuItem();

  fileMenu.getItems().addAll(newGame,resetGame,line,quit); //adding all menuitems to file menu


  //-------------------------------------------------------------
  //--------------------------------------------------------------
        //help menu
Menu helpMenu = new Menu("Help");
//-------------------------------------------------------

MenuItem About = new MenuItem("About the Game");
About.setOnAction(event -> aboutconnect() );

//--------------------------------------------------------

MenuItem me = new MenuItem("About me");
me.setOnAction(event -> Me());

//--------------------------------------------------------
        SeparatorMenuItem line1 = new SeparatorMenuItem();

helpMenu.getItems().addAll(About,line1,me); //adding all menuItems to helpMenu



  //-------------------------------------------------------------
//adding filement and helpmenu to menubar
MenuBar menuBar = new MenuBar();
menuBar.getMenus().addAll(fileMenu,helpMenu);


return menuBar;
    }

    private void Me() {
        //to show information about the Author
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About connect 4 developer");
        alert.setHeaderText(" Pawan Bharadwaj N P");
        alert.setContentText(" Thank you for playing the game. ");

        alert.show();

    }

    private void aboutconnect() {
//to show information about the game
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About connect 4 game");
        alert.setHeaderText("How to play? ");
        alert.setContentText(" connect four is a two-player game in which the " +
                " players first choose a color and then take turns dropping colored discs from the top into a seven" +
                "-coloumn , six-row vertically suspended grid . The pieces fall straight down, occupying the next available space within the coloumn.  "
        + " The objective of the game is to be  the first to form a horizonta, vertical, or diagnol line of four of one's own discs. "
        + " Connect four is a solved game. The first player can always win by playing the right moves.");

        alert.show();

    }


    private void Quit() {
        Platform.exit();
        System.exit(0);
            }

    private void ResetGame()
    {
controller.resetGame();
    }


    public static void main(String[] args) {
        launch(args);
    }
}

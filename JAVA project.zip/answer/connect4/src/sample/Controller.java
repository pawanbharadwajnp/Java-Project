package sample;

import javafx.scene.control.Button;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Point2D;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.util.Duration;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Controller implements Initializable {

private static  final int COL = 7;
private  static  final int  ROW= 6;
private static final int cicle_diameter = 80;
//default color of discs
private static final String discColor1 = "#24303E";
private static final String discColor2 = "#4CAA88";




	private boolean isplayer1turn = true;


	//default names  that may be changed
private static String Player_one = "Player One";
private static String Player_two = "Player Two";

private  Disc[][] insertedDIsc = new Disc[ROW][COL]; //structural changes for developers

	@FXML
	public GridPane rootgridpane;

@FXML
public Pane insertedpane;

@FXML
public Label p1label;
@FXML
		public Button submit;
@FXML
		public TextField p1;
@FXML
		public TextField p2;
	void call(){

		submit.setOnAction(event -> {

				Player_one = p1.getText().toString();
				Player_two = p2.getText().toString();

		});
	}

//for multiple insertion fix
	boolean isAllowedToInsert = true;

	private static void handle(ActionEvent event1) {
	}

	//to create rectangle that contains all the holes
public void  createPlayground(){
call();

	Shape rectangleWithHoles = InsertplayGround();

	rectangleWithHoles.setFill(Color.WHITE);
	rootgridpane.add(rectangleWithHoles,0,1);  //at oth col and 1st row there is pane where we add rectangle

	List<Rectangle> RectangleList = createHoverRectangles();

	//we add all rectangles to gridPane
	for (Rectangle rectangle: RectangleList) {
		rootgridpane.add(rectangle,0,1);
	}


}


private Shape InsertplayGround(){
call();
	Shape rectangleWithHoles = new Rectangle(  (COL+1) * cicle_diameter ,(1+ROW)*cicle_diameter ); //1+row/col increases extra row and coloumn so that background color does not mix with color holes

	//we need 2D array of circles
	for (int row =0 ; row < ROW ; row++){

		for (int col =0; col <COL ; col++) {


			Circle circle = new Circle(cicle_diameter / 2);
			circle.setCenterX(cicle_diameter / 2);
			circle.setCenterY(cicle_diameter / 2);
			circle.setSmooth(true);
//for each time rectangle row and col i.e x and y coordinates must be updated in order to
			//get a 2D of circles , so we need translate function to move the circle .

			circle.setTranslateX(col * (cicle_diameter + 5)  + cicle_diameter/4 );  //here cicle_diameter/4 is for adding extra row at top
			circle.setTranslateY(row * (cicle_diameter + 5) + cicle_diameter/4 );   //+5 for spaces between each circle

			/*
		 col->X-axis ----------------------------->
		 row->Y-axis
			|
			|
			|
			|
			|
			|
			|
			|


			 */


//to create holes in rectangle
			rectangleWithHoles = Shape.subtract(rectangleWithHoles, circle);



		}
	}

	return rectangleWithHoles;

}

@NotNull
private  List<Rectangle> createHoverRectangles(){
call();
	//we need 7 rectangles so that all coloums have a rectangle

	List<Rectangle> rectangleList  = new ArrayList<>();

	for (int col =0;col < COL ; col++){

		Rectangle  rectangle  = new Rectangle(cicle_diameter,(1+ROW)*cicle_diameter ); //here width is same as circle and height is same as white rectangle height
		rectangle.setFill(Color.TRANSPARENT);
		rectangle.setTranslateX(  col * (cicle_diameter + 5)  + cicle_diameter/4); //we shifted the circle by cicle_diameter/4 initially so we have to update this rectange so that this rectangle can be exactly covers circle

		//using hover effect
		rectangle.setOnMouseEntered(event -> rectangle.setFill(Color.valueOf("#00eeee10")));
		rectangle.setOnMouseExited(event -> rectangle.setFill(Color.TRANSPARENT));

	 final int coloumn = col; //to remove error only
		// to click event to insert the disc
		rectangle.setOnMouseClicked(event -> {
			//multiple insertion of disc bug fix
			if(isAllowedToInsert) {
				isAllowedToInsert=false; //when the disc is being dropped no more disc is inserted
				insertDisc(new Disc(isplayer1turn), coloumn); //insert the disc
			}
				});
		rectangleList.add(rectangle); //we add all rectangle to rectangle list      //and for col * (cicle_diameter + 5) is to cover all circles by rectangles.
	}



	return  rectangleList;
}


//to create disc
	private static class Disc extends Circle{

	private final boolean isplayeroneMove ;

	public Disc(boolean isplayeroneMove){
this.isplayeroneMove  =  isplayeroneMove;

setRadius(cicle_diameter/2); //same as circle in rectangle

//if player1 is playing we need different colors of disc to be inserted
		setFill(isplayeroneMove ? Color.valueOf(discColor1): Color.valueOf(discColor2));  //this actual code is Circe.setFill() but we extended Circle class so we can directly use the function

setCenterX(cicle_diameter/2);
setCenterY(cicle_diameter/2);

	}

}




//for inserting disc into the coloumn
private  void insertDisc( Disc disc , int coloumn){
call();

	int row = ROW-1;
	while(row>=0){ //to insert the disk one above the other
		if(getDiscIfPresent(row,coloumn) == null){
			break; //if array is empty we need to fill it so no decrement in row
		}
		row--;
	}
	if(row <0){
		return; //if row is full we cannot fill it ,so do nothing.
	}
	insertedDIsc[row][coloumn] = disc; //structural changes
	insertedpane.getChildren().add(disc); //for visual change
//horizontally we need to select the coloumn where we want to add
	disc.setTranslateX(coloumn * (cicle_diameter + 5)  + cicle_diameter/4); //this is for fitting the disc exactly to the holes in rectangle

	//for falling effect
	TranslateTransition transition = new TranslateTransition(Duration.seconds(0.5) , disc);

	transition.setToY(row * (cicle_diameter + 5)  + cicle_diameter/4);
//after one player inserts disk we need another player to insert
int currentrow = row; //to remove error in gameEnded()
	transition.setOnFinished(event -> {
isAllowedToInsert = true ; //after disc is dropped we can isert new disc
		if (gameEnded(currentrow,coloumn)){
			gameOver(); //display the winner
		}





		isplayer1turn = !isplayer1turn;
	p1label.setText(isplayer1turn?Player_one:Player_two);
	});


	transition.play();
}



	//game Ended
	private boolean gameEnded(int row,int coloumn){

//vertical points . A small example : Player has inserted his last disc at row =2 , coloumn=3


	List<Point2D>  verticalPoints =   IntStream.rangeClosed(row-3,row+3)  //range of row values = 0,1,2,3,4,5 and coloumn remains constant
			.mapToObj(r-> new Point2D(r,coloumn ))  //index of each element present in coloumn [row][coloumn = 3] : [0,3] [1,3] [2,3] [3,3]  [4,3]  [5,3]  -->point2D class holds value as x(row) ,y(coloumn) coordinates
  			.collect(Collectors.toList());
	//since coloumn is constant r changes time to time and collect is used to transform to  list objects



		List<Point2D>  horizontalPoints =   IntStream.rangeClosed(coloumn-3 ,coloumn+3)  //range of row values = 0,1,2,3,4,5 i.e =6
				.mapToObj(col -> new Point2D( row,col))  //index of each element present in coloumn [row][coloumn = 3] : [0,3] [1,3] [2,3] [3,3]  [4,3]  [5,3]  -->point2D class holds value as x(row) ,y(coloumn) coordinates
				.collect(Collectors.toList());
		//since coloumn is constant r changes time to time and collect is used to transform to  list objects



		//diagnol 1
		/*
				.( initial startpoint1)
			   .
			  .
			 .
			.
		 */
		Point2D startpoint1 = new Point2D(row-3,coloumn+3);

		List<Point2D> diagnol1  = IntStream.rangeClosed(0,6)
				.mapToObj(i -> startpoint1.add(i,-i)) //starting from that row row is incremented by 1 while coloumn is decremented by 1 that results in diagnol1
				.collect(Collectors.toList());

		//diagnol 2
		/*
		.
		 .
		  .
		   .
		    .
		 */
		Point2D startpoint2 = new Point2D(row-3,coloumn-3);
		List<Point2D> diagnol2  = IntStream.rangeClosed(0,6)
				.mapToObj(i -> startpoint2.add(i,i)) //starting from that row and coloumn is incremented by 1  that results in diagnol 2
				.collect(Collectors.toList());




		boolean isended = checkCombinations(verticalPoints) || checkCombinations(horizontalPoints)
				|| checkCombinations(diagnol1) || checkCombinations(diagnol2) ;


		return isended;
	}

	private boolean checkCombinations(@NotNull List<Point2D> Points) {
		int chain = 0;


		for (Point2D point : Points) {

			int rowIndex = (int) point.getX();
			int coloumnIndex = (int) point.getY();

			Disc disc = getDiscIfPresent(rowIndex,coloumnIndex);
			if (disc != null && disc.isplayeroneMove == isplayer1turn) {
				//then we have got the  right combination so we need chain of 4 discs
				chain++;
				if (chain == 4) {
					return true; //4 discs are matched
				}
			}else {
					chain = 0;
				}
			
		}
return false;
	}

	//to remove ArrayIndexOutOfBoundException if not return disc or null at that location
	@Nullable
	@Contract(pure = true)
	private Disc  getDiscIfPresent(int rowIndex , int coloumnIndex){
if(rowIndex>= ROW || rowIndex <0 || coloumnIndex>= COL || coloumnIndex<0 )
	return null;

	return   insertedDIsc[rowIndex][coloumnIndex];
}


	@Override
	public void initialize(URL location, ResourceBundle resources) {



	}



 	private void gameOver() { //to display whi won
		String winner =  isplayer1turn? Player_one:Player_two;
		System.out.println("Winner is " + winner);

		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setTitle("Connect four");
		alert.setHeaderText("The Winner is " + winner);
		alert.setContentText("Want to play again?  go to file option.");
		alert.show();






		//now we need 2  button
//
//		ButtonType yeabutton = new ButtonType("Yes");
//
//		ButtonType exit = new ButtonType("no");
//		alert.getButtonTypes().setAll(yeabutton,exit);
// //after the animation  we want to execute this else error appears
//
//		 Platform.runLater(  () -> {
//
//			 Optional<ButtonType> onclick = alert.showAndWait();
//
//
//			if(onclick.isPresent() && (onclick.get() == yeabutton)){
//				resetGame();
//
//			}
//			else
//			{
//				Platform.exit();
//				System.exit(0);
//			}
//
//
//		}  );


}

	public void resetGame() {

	insertedpane.getChildren().clear(); //removes all discs in graphics

		//removes structurally
		for ( int  row =0; row<insertedDIsc.length ;row++){
			for (int c=0;c<insertedDIsc[row].length;c++){
insertedDIsc[row][c] = null;

			}
		}

		isplayer1turn=true;

		p1label.setText(Player_one);


		createPlayground(); //new playground

	}

}
